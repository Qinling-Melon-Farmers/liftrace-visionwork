"""Read-only resource fallback over SSH, without taking another ROS probe's lock."""
import ast
import base64
import json
from pathlib import Path
import threading
import time
from wb_ssh import quote


def remote_source():
    # AST extraction works on Windows; importing board_probe would require fcntl.
    text=Path(__file__).with_name('board_probe.py').read_text(encoding='utf-8')
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='ResourceSampler')
    return ('import json,os,re,time\nfrom pathlib import Path\n'+ast.get_source_segment(text,node)+
            '\nsampler=ResourceSampler()\nsampler.sample()\ntime.sleep(0.25)\n'
            'result=sampler.sample()\nresult["age_seconds"]=0.0\n'
            'print(json.dumps(result,allow_nan=False))\n')


class ResourceClient:
    def __init__(self,board):
        self.board=board
        self.lock=threading.Lock()
        self.cached=None
        self.scope=None
        self.last=0

    def sample(self):
        scope=(self.board.target.host,self.board.target.port,self.board.root)
        with self.lock:
            if scope==self.scope and self.cached and time.monotonic()-self.last<2:
                return self.cached
            encoded=base64.b64encode(remote_source().encode()).decode()
            code='import base64;exec(compile(base64.b64decode(%r),"resource_sampler","exec"))'%encoded
            python=self.board.config['connection'].get('board_python','/usr/bin/python3')
            command='cd %s && %s -c %s'%(quote(self.board.root),quote(python),quote(code))
            status,output=self.board.run(command,timeout=8)
            if status:raise ValueError('只读资源采样失败：'+str(output)[-300:])
            try:
                resource=json.loads(output.strip().splitlines()[-1])
                if not isinstance(resource,dict) or not isinstance(resource.get('cpu'),dict):raise ValueError()
            except (ValueError,IndexError):raise ValueError('板端资源采样返回格式无效')
            self.cached=dict(ok=True,at=time.time(),resources=resource,source='SSH独立只读采样')
            self.last=time.monotonic();self.scope=scope
            return self.cached
