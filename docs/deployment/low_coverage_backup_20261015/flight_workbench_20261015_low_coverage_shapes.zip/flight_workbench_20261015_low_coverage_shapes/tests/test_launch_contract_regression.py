"""Preview/start consistency without SSH, ROS or actuator execution."""
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import tempfile
import unittest
import sys
import yaml
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server, wb_board, wb_geometry, wb_competition_geometry, wb_config_summary

class LaunchContractRegression(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        for obj,name in [(server,'PROFILE_DIR'),(wb_board,'DEFAULT_PROFILE_DIR')]:
            p=patch.object(obj,name,self.tmp.name);p.start();self.addCleanup(p.stop)
        self.wb=server.Workbench(wb_board.load_config(),{'transport':'ssh'})
        self.wb.connection['state']='ok'
        p=patch.object(self.wb.board,'run',side_effect=AssertionError('no remote calls in regression'))
        p.start();self.addCleanup(p.stop)
        self.root=Path(__file__).resolve().parents[1]
    def cases(self):
        site=yaml.safe_load((self.root/'waypoint_templates/module08.yaml').read_text())
        module={k:copy.deepcopy(site[k]) for k in ('flight_area','corridor_waypoints','landing_xy','high_agl','low_agl','max_agl') if k in site}
        field=yaml.safe_load((self.root/'competition_templates/deployment/competition/field_10x10_default.yaml').read_text())
        formal=wb_config_summary.summarize(field)['geometry']
        group=next(g for g in self.wb.config['groups'] if g['channel']=='competition')
        return [(wb_geometry,dict(group_id='mod08',route='module',mode='flight',real_release=False,confirm='启动试飞',site_geometry=module,geometry_revision='sameDraft1')),
                (wb_competition_geometry,dict(group_id=group['id'],route='competition',mode='flight',real_release=True,confirm='实投',site_geometry=formal,geometry_revision='sameDraft1'))]
    def test_preview_then_start_after_minute_rollover(self):
        for module,body in self.cases():
            with self.subTest(group=body['group_id']),patch.object(module,'datetime',create=True) as clock:
                clock.now.return_value=datetime(2026,10,15,15,0,59,tzinfo=timezone(timedelta(hours=8)))
                preview=self.wb.trial_command(body)['body']
                clock.now.return_value=datetime(2026,10,15,15,1,1,tzinfo=timezone(timedelta(hours=8)))
                session=SimpleNamespace(snapshot=lambda:{'state':'running'})
                with patch.object(self.wb.sessions,'open',return_value=session) as opened:
                    result=self.wb.start_trial(dict(body,expected_body=preview))
                    self.assertTrue(result['ok']);opened.assert_called_once()
                    self.assertEqual(result['trial']['command'],preview)
    def test_coordinate_revision_and_source_are_bound_without_wall_clock(self):
        geometry={'high_agl':2.6}
        one=wb_geometry.overlay_command('field.yaml','08_full_mission',geometry,'r1')[0]
        self.assertEqual(one,wb_geometry.overlay_command('field.yaml','08_full_mission',geometry,'r1')[0])
        for source,change,rev in [('field.yaml',{'high_agl':2.7},'r1'),('other.yaml',geometry,'r1'),('field.yaml',geometry,'r2')]:
            self.assertNotEqual(one,wb_geometry.overlay_command(source,'08_full_mission',change,rev)[0])
    def test_formal_switches_have_separate_immutable_outputs(self):
        _,body=self.cases()[1];g=body['site_geometry']
        one=wb_competition_geometry.overlay_command('field.yaml',g,'r1',motion='on')[0]
        for change in ({'motion':'off'},{'motion':'on','columns':'off'},{'motion':'on','resume':'off'}):
            self.assertNotEqual(one,wb_competition_geometry.overlay_command('field.yaml',g,'r1',**change)[0])
    def test_changed_preview_still_rejected_before_session(self):
        _,body=self.cases()[0]
        expected=self.wb.trial_command(body)['body']
        changed=copy.deepcopy(body);changed['site_geometry']['high_agl']=2.7
        with patch.object(self.wb.sessions,'open') as opened,self.assertRaisesRegex(ValueError,'不一致'):
            self.wb.start_trial(dict(changed,expected_body=expected))
        opened.assert_not_called()

if __name__=='__main__':unittest.main(verbosity=2)