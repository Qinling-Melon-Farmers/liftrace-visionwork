"""Command adapter used only by the separate WSL simulation configuration."""
import copy
import base64
import hashlib
import json
import shlex


def competition_command(config, group, mode, **options):
    import wb_board
    import wb_flight_settings
    if options.get('real_release') or options.get('route') not in (None, 'competition'):
        raise ValueError('独立正赛仿真仅允许mock投递和正赛入口')
    original = copy.deepcopy(config)
    original.pop('simulation', None)
    params = dict(options, real_release=True, flight_settings=None)
    command, _ = wb_board.build_group_command(original, group, mode, **params)
    entry = 'bash '+shlex.quote(group.get('entry', 'deployment/competition/start.sh'))+' '
    if entry not in command: raise ValueError('无法识别独立正赛入口')
    command = command.replace(entry, 'bash deployment/workbench_sim/start.sh competition ', 1)
    seed = group.get('scene_seed', 11)
    if type(seed) is not int or not 0 <= seed <= 2147483647: raise ValueError('无效场景seed')
    command += ' --scene-seed '+str(seed)
    if options.get('flight_settings') is not None:
        patch = wb_flight_settings.validate_patch(options['flight_settings'], 'competition')
        data = json.dumps(patch, sort_keys=True, separators=(',',':'), allow_nan=False)
        path = 'logs/flight_workbench/flight_overlays/competition_sim_'+hashlib.sha256(data.encode()).hexdigest()[:20]+'.yaml'
        writer = """import base64,pathlib,sys
p=(pathlib.Path.cwd()/sys.argv[1]).resolve()
if pathlib.Path.cwd().resolve() not in p.parents:raise ValueError('overlay outside project')
text=base64.b64decode(sys.argv[2]).decode()
p.parent.mkdir(parents=True,exist_ok=True)
if p.exists() and p.read_text()!=text:raise ValueError('overlay conflict')
if not p.exists():p.write_text(text)
"""
        command = 'python3 -c '+shlex.quote(writer)+' '+shlex.quote(path)+' '+shlex.quote(base64.b64encode(data.encode()).decode())+' && '+command+' --flight-config '+shlex.quote(path)
    return command, '独立正赛SITL：复用正式配置和任务策略；大场地/靶标按配置生成，投递仅mock。'


def simulation_probe_source(source):
    # SITL starts a new ROS master each run. A surviving rospy subscriber must
    # register anew when its node disappears from that master.
    marker = '        now = time.time()\n        if now - node_read'
    replacement = '''        try:
            import rosgraph
            rosgraph.Master('/' + args.node_name).lookupNode('/' + args.node_name)
        except Exception:
            emitter(False, {'error': 'SITL master restarted; re-registering probe'})
            reexec_probe(max(2.0, interval))
        now = time.time()
        if now - node_read'''
    if source.count(marker) != 1:
        raise ValueError('仿真探针适配位置已变化，请检查board_probe版本')
    return source.replace(marker, replacement, 1)


def build_command(config, group, mode, **options):
    import wb_board
    if group.get('channel') == 'competition' and group.get('simulation') is True:
        return competition_command(config, group, mode, **options)
    if group.get('folder') != '08_full_mission':
        raise ValueError('当前 WSL 仿真配置只支持08整场')
    if options.get('real_release') or options.get('route') not in (None, 'module'):
        raise ValueError('WSL 仿真仅支持模块入口和mock投递')
    original = copy.deepcopy(config)
    original.pop('simulation', None)
    original_options = dict(options, motion_optimization=None, obstacle_columns=None)
    command, note = wb_board.build_group_command(original, group, mode, **original_options)
    entry = 'bash deployment/board_trials_4x4/08_full_mission/start.sh '
    if entry not in command:
        raise ValueError('无法识别08入口，未启动仿真')
    command = command.replace(entry, 'bash deployment/workbench_sim/start.sh full_mission ', 1)
    for key, flag in (('motion_optimization', '--motion-optimization'),
                      ('obstacle_columns', '--obstacle-columns')):
        value = options.get(key)
        if value is not None:
            if value not in ('on', 'off'): raise ValueError('无效仿真开关 '+key)
            command += ' '+flag+' '+value
    return command, 'WSL SITL / mock；preview只生成配置；flight自动模拟起飞。' + note
