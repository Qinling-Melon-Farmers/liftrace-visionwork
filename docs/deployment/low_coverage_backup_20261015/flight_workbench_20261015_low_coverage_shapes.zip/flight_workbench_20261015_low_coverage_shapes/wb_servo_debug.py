"""Integrate the deployed SetServoDuty service; never upload or start hardware implicitly."""
import base64
import json
import threading

import wb_board
from wb_ssh import quote


REMOTE = r'''
import json, pathlib, re, sys, time
root=pathlib.Path.cwd()
request=json.loads(sys.argv[1]); action=request['action']
devices=['febf0000.pwm','febf0020.pwm','febf0010.pwm']
paths=[]
for device in devices:
    matches=[p/'pwm0' for p in pathlib.Path('/sys/class/pwm').glob('pwmchip*') if '/'+device+'/' in p.resolve().as_posix()]
    paths.append(matches[0] if len(matches)==1 else None)
def read(path,name):
    try:return (path/name).read_text().strip()
    except (OSError,TypeError):return None
def channels():
    return [dict(slot=i+1,duty_cycle_ns=int(read(p,'duty_cycle')) if read(p,'duty_cycle') is not None else None,
                 enabled=read(p,'enable')=='1',initialized=read(p,'period')=='20000000' and read(p,'polarity')=='normal') for i,p in enumerate(paths)]
def grounded():
    import subprocess
    ps=subprocess.check_output(['ps','-eo','args'],text=True)
    for line in ps.splitlines():
        if line.lstrip().startswith(('python','/usr/bin/python','/home/')) and any(x in line for x in ['run_trial.py','competition_supervisor.py','/lib/patrol_control/patrol_control']):
            raise ValueError('任务控制进程正在运行；请结束飞行任务后调试')
    import rospy, rosgraph
    rospy.init_node('workbench_servo_debug_client',anonymous=True,disable_signals=True)
    master=rosgraph.Master(rospy.get_name())
    publishers=master.getSystemState()[0]
    if any(name=='/mavros/state' and nodes for name,nodes in publishers):
        from mavros_msgs.msg import State
        state=rospy.wait_for_message('/mavros/state',State,timeout=2)
        if state.armed:raise ValueError('飞控已解锁，禁止舵机地面调试')
if action=='status':
    text=(root/'patrol_uav_ws-patrol_planner/src/actuator_pwm/include/actuator_pwm/SlotCalibration.h').read_text()
    def calibration(name):
        match=re.search(name+r'\[\]\s*=\s*\{([^}]+)\}',text)
        if not match:raise ValueError('板端舵机标定表无法解析')
        values=[int(x.strip()) for x in match.group(1).split(',')]
        if len(values)!=3:raise ValueError('标定表必须包含三通道')
        return values
    available=False; detail=''
    try:
        import rosgraph
        services=rosgraph.Master('/workbench_servo_status').getSystemState()[2]
        available=any(name=='/SetServoDuty' and nodes for name,nodes in services)
    except Exception as e:detail=str(e)
    print(json.dumps(dict(ok=True,channels=channels(),initial_ns=calibration('kInitialDutyNs'),
        release_ns=calibration('kReleaseDutyNs'),service_available=available,detail=detail)))
elif action=='guard':
    grounded()
    from patrol_control.srv import SetServoDuty
    script=root/'patrol_uav_ws-patrol_planner/src/actuator_pwm/scripts/servo_debug_node.py'
    if not script.exists():raise ValueError('板端尚未部署servo_debug_node.py')
    if not all(c['initialized'] and not c['enabled'] for c in channels()):
        raise ValueError('请先通过原PWM初始化入口初始化并关闭三路输出')
elif action=='set':
    grounded()
    if not channels()[request['slot']-1]['initialized']:
        raise ValueError('PWM周期或极性不符合20ms/normal；请先初始化')
    from patrol_control.srv import SetServoDuty
    rospy.wait_for_service('/SetServoDuty',timeout=2)
    import rosservice
    if rosservice.get_service_type('/SetServoDuty')!='patrol_control/SetServoDuty':raise ValueError('舵机服务类型不匹配')
    result=rospy.ServiceProxy('/SetServoDuty',SetServoDuty)(request['slot'],request['duty_cycle_ns'],request['hold'])
    print(json.dumps(dict(ok=bool(result.success),message=result.message,actual_duty_ns=result.actual_duty_ns,channels=channels())))
elif action=='stop':
    # No minimum/initial pulse: output disable only, preserving the last duty.
    errors=[]
    for i,p in enumerate(paths):
        if p is None or not (p/'enable').exists():continue
        try:
            if read(p,'enable')!='0':(p/'enable').write_text('0')
            if read(p,'enable')!='0':raise ValueError('PWM关闭读回失败')
        except Exception as e:errors.append('slot %d: %s'%(i+1,e))
    print(json.dumps(dict(ok=not errors,message='; '.join(errors) or '三路PWM输出已关闭，脉宽未改变',channels=channels())))
else:raise ValueError('未知动作')
'''


def validate_set(body):
    if not isinstance(body, dict) or body.get('confirm') != '舵机调试':
        raise ValueError('请确认舵机调试动作')
    slot, duty, hold = body.get('slot'), body.get('duty_cycle_ns'), body.get('hold', False)
    if type(slot) is not int or not 1 <= slot <= 3:
        raise ValueError('slot必须为1、2或3')
    if type(duty) is not int or not 500000 <= duty <= 2500000:
        raise ValueError('脉宽必须为500000～2500000 ns（0.5～2.5 ms）')
    if type(hold) is not bool:
        raise ValueError('hold必须是布尔值')
    return dict(action='set',slot=slot,duty_cycle_ns=duty,hold=hold)


class ServoDebug:
    def __init__(self, workbench):
        self.w = workbench
        self.lock = threading.Lock()

    def command(self, request):
        encoded=base64.b64encode(REMOTE.encode()).decode()
        body=json.dumps(request,separators=(',',':'))
        script='import base64; exec(compile(base64.b64decode(%r),"servo_workbench","exec"))'%encoded
        return wb_board.terminal_wrapped_command(self.w.config,
            '%s -c %s %s'%(quote(self.w.config['connection'].get('board_python','/usr/bin/python3')),quote(script),quote(body)))

    def run(self, request):
        code, output=self.w.board.run(self.command(request),timeout=12)
        if code:raise ValueError('板端舵机接口失败：'+str(output)[-1500:])
        try:return json.loads(str(output).strip().splitlines()[-1])
        except (ValueError,IndexError):raise ValueError('板端没有返回有效舵机结果')

    def active(self):
        s=self.w.sessions.get('servo_debug')
        return bool(s and s.state in ('starting','running'))

    def action(self, name, body):
        self.w._require_command_transport()
        if self.w.connection.get('state') != 'ok':raise ValueError('请先连接板端')
        if name=='status':
            result=self.run(dict(action='status'))
            session=self.w.sessions.get('servo_debug')
            if session:
                result['backend_state']=session.state
                result['backend_output']=''.join(text for _,text in session.history_since(0))[-2500:]
            return result
        if name=='set':request=validate_set(body)
        elif name in ('start','stop','close'):
            if not isinstance(body,dict) or body.get('confirm')!='舵机调试':raise ValueError('请确认舵机调试操作')
            request=dict(action='stop')
        else:raise ValueError('未知舵机操作')
        with self.lock:
            trial=self.w.sessions.get('trial')
            if name!='stop' and trial and trial.state in ('starting','running'):
                raise ValueError('请结束当前试飞入口再调试舵机')
            if name=='start':
                if self.active():return dict(ok=True,message='调试后端已启动')
                if self.run(dict(action='status')).get('service_available'):
                    return dict(ok=True,message='板端已有调试服务，复用已有后端，不重复启动')
                command=self.command(dict(action='guard'))+' && '+wb_board.terminal_wrapped_command(
                    self.w.config,'exec rosrun actuator_pwm servo_debug_node.py')
                self.w.sessions.open('servo_debug','舵机调试后端',command,self.w.target)
                return dict(ok=True,message='调试后端启动请求已提交；刷新状态确认服务就绪')
            result=self.run(request)
            if name=='close' and result.get('ok'):self.w.sessions.close('servo_debug')
            self.w._journal(dict(action='servo_debug_'+name,request=request,result=result))
            return result
