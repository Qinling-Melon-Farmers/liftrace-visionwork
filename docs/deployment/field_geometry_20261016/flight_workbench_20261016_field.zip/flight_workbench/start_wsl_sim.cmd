@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_wsl_sim.ps1" -Open
pause
