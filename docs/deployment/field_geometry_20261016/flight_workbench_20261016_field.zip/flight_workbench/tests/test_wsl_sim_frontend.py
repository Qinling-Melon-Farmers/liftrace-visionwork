"""Compare browser command previews with the actual backend commands."""
import json
from pathlib import Path
import subprocess
import unittest
import wb_board


class BrowserCommandParity(unittest.TestCase):
    def test_mock_simulation_and_real_competition_previews_match_backend(self):
        sim=wb_board.load_config('workbench_wsl_sim.yaml')
        real=wb_board.load_config('workbench.yaml')
        cases=[]
        for config,ident,release in ((sim,'mod08',False),(sim,'competition_sim',False),(real,'competition',True)):
            group=next(g for g in config['groups'] if g['id']==ident)
            for check in (True,False):
                body,_=wb_board.build_group_command(config,group,'flight',real_release=release,check_config=check)
                cases.append(dict(group=group,check=check,release=release,expected=body))
        app=Path('web/app.js').read_text(encoding='utf-8')
        snippet=app[app.index('function shQuote('):app.index('function groupCommandBody(')]
        snippet+=app[app.index('function groupCommandBody('):app.index('function buildTrialCommand(')]
        code="const fs=require('fs');var state={connection:{}};"+snippet+"\nconst cases=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(cases.map(c=>groupCommandBody(c.group,'flight',c.release,c.check,null,{}).body)));"
        result=subprocess.run(['node','-e',code],input=json.dumps(cases),text=True,capture_output=True,check=True)
        self.assertEqual(json.loads(result.stdout),[c['expected'] for c in cases])
