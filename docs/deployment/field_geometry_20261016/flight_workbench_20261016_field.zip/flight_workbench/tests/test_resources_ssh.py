import ast
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from wb_resources import ResourceClient,remote_source


class ResourceSSHTests(unittest.TestCase):
    def board(self):
        calls=[]
        def run(command,timeout):
            calls.append(command)
            return 0,json.dumps({'cpu':{'percent':12},'age_seconds':0})
        return SimpleNamespace(target=SimpleNamespace(host='user@board',port=22),root='/home/user/repo',
            config={'connection':{}},run=run),calls

    def test_cache_and_target_switch(self):
        b,calls=self.board();client=ResourceClient(b)
        first=client.sample();self.assertTrue(first['ok']);self.assertEqual(first,client.sample());self.assertEqual(len(calls),1)
        b.target.host='user@another';client.sample();self.assertEqual(len(calls),2)

    def test_ssh_failure_never_fabricates_zero_values(self):
        b,_=self.board();b.run=lambda *a,**k:(1,'SSH failure')
        with self.assertRaisesRegex(ValueError,'SSH failure'):ResourceClient(b).sample()

    def test_malformed_sample_rejected(self):
        b,_=self.board();b.run=lambda *a,**k:(0,'{"cpu":0}')
        with self.assertRaises(ValueError):ResourceClient(b).sample()

    def test_remote_source_has_no_ros_or_probe_lock(self):
        source=remote_source();ast.parse(source)
        self.assertNotIn('rospy',source);self.assertNotIn('fcntl',source);self.assertNotIn('flock',source)
        self.assertIn('time.sleep(0.25)',source)

if __name__=='__main__':unittest.main()
