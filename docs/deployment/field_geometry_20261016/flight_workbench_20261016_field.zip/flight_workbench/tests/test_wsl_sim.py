import unittest
import wb_board


class SimulationCommands(unittest.TestCase):
    def setUp(self):
        self.config = wb_board.load_config('workbench_wsl_sim.yaml')
        self.group = self.config['groups'][0]

    def test_overlays_keep_simulation_entry(self):
        body, _ = wb_board.build_group_command(self.config, self.group, 'flight',
            flight_settings={'drop_agl': .35}, speed_profile='competition')
        self.assertIn('deployment/workbench_sim/start.sh full_mission flight', body)
        self.assertIn('--flight-config', body)
        self.assertIn('--speed-profile competition', body)
        self.assertNotIn('start_real.sh', body)

    def test_hardware_routes_rejected(self):
        for options in ({'real_release': True}, {'route': 'site'}):
            with self.assertRaises(ValueError):
                wb_board.build_group_command(self.config, self.group, 'flight', **options)

    def test_hardware_profile_keeps_original_entry(self):
        config = wb_board.load_config('workbench.yaml')
        group = next(g for g in config['groups'] if g['id'] == 'mod08')
        body, _ = wb_board.build_group_command(config, group, 'preview', check_config=True)
        self.assertIn('deployment/board_trials_4x4/08_full_mission/start.sh', body)
        self.assertNotIn('workbench_sim', body)

    def test_probe_reregistration_is_simulation_only(self):
        import ast
        from pathlib import Path
        from wb_sim import simulation_probe_source
        original=Path('board_probe.py').read_text(encoding='utf-8')
        adapted=simulation_probe_source(original)
        ast.parse(adapted)
        self.assertIn('SITL master restarted', adapted)
        self.assertNotIn('SITL master restarted', original)

    def test_simulation_switches_with_parameter_overlay(self):
        body, _ = wb_board.build_group_command(self.config, self.group, 'preview',
            flight_settings={'drop_agl': .35}, motion_optimization='off', obstacle_columns='off')
        self.assertIn('--motion-optimization off', body)
        self.assertIn('--obstacle-columns off', body)

    def test_competition_mock_and_real_hardware_boundary(self):
        group=next(g for g in self.config['groups'] if g['id']=='competition_sim')
        body,_=wb_board.build_group_command(self.config,group,'flight',real_release=False,
            motion_optimization='off',flight_settings={'drop_agl':.35})
        self.assertIn('start.sh competition flight',body)
        self.assertIn('--scene-seed 11',body)
        self.assertIn('--flight-config',body)
        with self.assertRaises(ValueError):
            wb_board.build_group_command(self.config,group,'flight',real_release=True)
        real=wb_board.load_config('workbench.yaml')
        hardware=next(g for g in real['groups'] if g['id']=='competition')
        with self.assertRaises(ValueError):
            wb_board.build_group_command(real,hardware,'flight',real_release=False)
