import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import wb_servo_debug as servo


class ServoIntegrationTests(unittest.TestCase):
    def test_service_fields_and_boundaries(self):
        for slot in (1,2,3):
            for duty in (500000,1800000,2500000):
                r=servo.validate_set(dict(confirm='舵机调试',slot=slot,duty_cycle_ns=duty,hold=True))
                self.assertEqual(r,dict(action='set',slot=slot,duty_cycle_ns=duty,hold=True))

    def test_invalid_requests_never_reach_board(self):
        for change in ({'slot':True},{'slot':4},{'duty_cycle_ns':499999},{'duty_cycle_ns':2500001},{'hold':'false'},{'confirm':''}):
            body=dict(confirm='舵机调试',slot=1,duty_cycle_ns=1800000,hold=False);body.update(change)
            with self.assertRaises(ValueError):servo.validate_set(body)

    def remote(self,action):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);pwm=root/'pwm';pwm.mkdir()
            for i,device in enumerate(('febf0000.pwm','febf0020.pwm','febf0010.pwm')):
                p=pwm/device/'pwmchip0'/'pwm0';p.mkdir(parents=True)
                for name,val in dict(duty_cycle='1800000',enable='1',period='20000000',polarity='normal').items():(p/name).write_text(val)
            calibration=root/'patrol_uav_ws-patrol_planner/src/actuator_pwm/include/actuator_pwm/SlotCalibration.h';calibration.parent.mkdir(parents=True)
            calibration.write_text('kInitialDutyNs[] = {600000,1000000,1100000};\nkReleaseDutyNs[] = {1800000,2100000,2100000};')
            source=servo.REMOTE.replace("pathlib.Path('/sys/class/pwm').glob('pwmchip*')",'pathlib.Path(%r).glob("*/pwmchip*")'%str(pwm))
            graph=types.SimpleNamespace(Master=lambda name:types.SimpleNamespace(getSystemState=lambda:([],[],[('/SetServoDuty',['debug'])])))
            old=os.getcwd();out=io.StringIO()
            try:
                os.chdir(root)
                with patch.object(sys,'argv',['client',json.dumps(dict(action=action))]),patch.dict(sys.modules,{'rosgraph':graph}),contextlib.redirect_stdout(out):exec(compile(source,'remote','exec'),{})
            finally:os.chdir(old)
            result=json.loads(out.getvalue().strip().splitlines()[-1])
            duties=[(p/'duty_cycle').read_text() for p in pwm.glob('*/pwmchip*/pwm0')]
            enables=[(p/'enable').read_text() for p in pwm.glob('*/pwmchip*/pwm0')]
            return result,duties,enables

    def test_stop_disables_without_moving_or_changing_duty(self):
        r,duties,enables=self.remote('stop');self.assertTrue(r['ok'])
        self.assertEqual(duties,['1800000']*3);self.assertEqual(enables,['0']*3)

    def test_status_uses_current_board_calibration_and_preserves_outputs(self):
        r,duties,enables=self.remote('status');self.assertEqual(r['initial_ns'][0],600000)
        self.assertEqual(r['release_ns'][0],1800000);self.assertTrue(r['service_available'])
        self.assertEqual(r['channels'][0]['duty_cycle_ns'],1800000)
        self.assertEqual(enables,['1']*3)

    def test_disconnected_rejects_without_ssh(self):
        w=types.SimpleNamespace(connection={'state':'unknown'},_require_command_transport=lambda:None)
        with self.assertRaises(ValueError):servo.ServoDebug(w).action('status',{})

    def test_active_debug_session_identified(self):
        w=types.SimpleNamespace(sessions=types.SimpleNamespace(get=lambda sid:types.SimpleNamespace(state='running')))
        self.assertTrue(servo.ServoDebug(w).active())

if __name__=='__main__':unittest.main()
