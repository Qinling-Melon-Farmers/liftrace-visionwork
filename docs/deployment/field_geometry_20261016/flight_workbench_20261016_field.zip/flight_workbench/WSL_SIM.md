# Windows工作台连接WSL仿真

双击 `start_wsl_sim.cmd`，打开终端打印的地址，默认 http://127.0.0.1:8781 。
当前仿真工作台已经运行，可以直接访问该地址。

使用独立 `workbench_wsl_sim.yaml` 和 `%LOCALAPPDATA%/liftrace-workbench-wsl-sim` 状态目录；原 `workbench.yaml`、香橙派配置和原入口保持不变。

## 本机环境

- WSL发行版：`U20.04-UAV`，SSH：`lh@127.0.0.1:2222`。
- 仿真源码：`/home/lh/liftrace-workbench-sim-20261014`，来自当前导航仓库的本地clone。
- 推理环境：`/home/lh/.venvs/liftrace-workbench-sim`，Python3.10、CPU PyTorch2.5.1、Ultralytics8.3.203。
- 权重：`runtime_models/workbench_sim.pt`，来自用户提供的20261011五类候选压缩包。
- PX4 SITL：复用 `/home/lh/PX4-Autopilot-TouDi`，用 `PX4_SYS_AUTOSTART=10015` 选择已有Iris启动配置；雷达插件复用 `/home/lh/patrol_sim_ws/devel/lib`。
- 仿真模型资源从已有WSL工程复制到新clone的 `simulation_assets/models`，不进入Git。
- SSH密钥和服务器配置保存在个人目录，不打包或提交。

## 使用

1. 点击连接；无需启动硬件设备终端。
2. 08卡片“配置检查”与“preview”仅生成配置，不启动ROS或飞行。
3. 可以读取投递/H参数、修改参数和地图航点，再检查实际生成配置。
4. “flight”启动Gazebo、PX4 SITL、定位建图、导航控制和视觉链；自动模拟解锁起飞，投递仅mock。
5. 实时观察页查看状态/位姿，日志页查询并下载bag和运行配置。可选持续同步沿用既有日志功能。
6. 用工作台停止任务，等待后台收尾；再次运行会自动重注册探针。

08组使用固定4×4测试场景，包含虚拟雷达、下视相机、三个目标、两门和H。地图编辑改变导航目标，并移动H标记，不会重建固定墙、门或目标；需要保证编辑后的航点与场景相符。

新增“独立正赛仿真 · 10×10大场地”，复用真实正赛的场地选项、地图导入/编辑、投递/H参数、运动优化、续扫及障碍柱开关、状态/日志流程。使用真实 `competition_config.generate` 和 `CompetitionManager`/`HardwareFullRuntime`；硬件入口的拒绝仿真及真实投递约束保持不变，独立shim负责SITL接线。

默认正赛配置生成飞行边界、搜索/覆盖路线、走廊及H；场景包含四组原大场地树箱、五类随机靶标、两道通口。固定seed11，可在独立仿真配置的该卡片 `scene_seed` 更改。通口宽度0.80m、树箱及室内环境为已有世界的假设，分隔墙/通口位置依据路线与墙面参数推导；这是与航点一致的模拟布局，不冒充实测复刻。靶标位置只进入scene.world/scene.json，任务不读取真值。

正赛仿真允许使用原文件中 `site_confirmed: false` 的完整几何配置，仅在生成器的内存副本标记可生成；原文件的现场确认值不改变。mock只模拟受保护投递服务与ACK，没有投放物下落/落点物理。

SITL没有飞手完成POSCTL降落，默认把 `vh + POSCTL` 转换为 `non_vh + AUTO.LAND`，请求值和实际值写入生成配置。OFFBOARD候选保留其原策略。仿真结果不能代替实机vh/POSCTL交接、RKNN实时性能或机械实投验收。

## 构建与记录

两套ROS工作区在本机WSL实际构建。原仓库CMakeLists重复注册 `test_release_invocation_recovery.py`，关闭测试又遇到Fast-Planner未加条件的gtest目标，因此仅在隔离clone删掉一次重复注册，再保持测试目标开启完成构建；未修改原导航仓库该文件或业务逻辑。下次构建可运行clone内 `bash deployment/workbench_sim/build.sh`。

原WSL旧工程、工作台已有未提交修改均保留。首轮PX4启动失败及后续联调日志保留于clone的 `logs/board_full_mission_wsl_*`。

2026-10-14实际验证：Windows HTTP页面/SSH连接、08配置检查、参数读取与覆盖、模拟自动起飞并进入SEARCH、位姿与任务遥测、WSLg相机图像、CPU YOLO诊断输出、运行日志索引/下载均通过。最终录包 `board_full_mission_wsl_20261014_200150/flight_debug_0.bag` 约76MiB，录制报告PASS、正常封闭、录制进程退出码0；停止后无ROS/Gazebo/PX4/RViz/rosbag录制残留。

这是连接与执行链的联调，主动停止于SEARCH，尚未验收完整三投/走廊/H全任务成功。源码是本次开始时的独立快照；原工程后续修改需要同步到clone，对C++改动重新构建。

独立正赛新增功能已通过离线配置/世界生成、真实参数继承、mock边界、seed可复现、前后端命令一致和ROS launch参数展开检查；本次未自动启动正赛飞行，完整任务动态验收仍待用户启动。
