param([int]$Port = 8781, [switch]$Open)
$ErrorActionPreference = 'Stop'
# Separate configuration/profile; never changes the Orange Pi profile.
wsl -d U20.04-UAV -u root -e bash /home/lh/liftrace-workbench-sim-20261014/deployment/workbench_sim/start_ssh.sh
if ($LASTEXITCODE -ne 0) { throw 'WSL simulation SSH failed to start' }
$taskPython = (Get-Command python.exe -ErrorAction Stop).Source
$taskArgs = @((Join-Path $PSScriptRoot 'server.py'), '--host', '127.0.0.1', '--port', [string]$Port,
    '--config', (Join-Path $PSScriptRoot 'workbench_wsl_sim.yaml'), '--profile-dir', (Join-Path $env:LOCALAPPDATA 'liftrace-workbench-wsl-sim'))
if ($Open) { $taskArgs += '--open' }
& $taskPython @taskArgs
