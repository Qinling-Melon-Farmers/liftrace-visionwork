'use strict';
const rows=[], statusLine=document.querySelector('#status'), resultBox=document.querySelector('#result');
let latest=null,busy=false;
async function api(action,body={}){const r=await fetch('/api/servo/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const v=await r.json();if(!r.ok||v.ok===false)throw Error(v.error||v.message||'操作失败');return v;}
function controls(){rows.forEach(r=>r.send.disabled=busy||!latest?.service_available||!document.querySelector('#ground').checked);document.querySelector('#start').disabled=busy;document.querySelector('#close').disabled=busy;}
async function refresh(){try{latest=await api('status');statusLine.textContent=latest.service_available?'调试服务已就绪 /SetServoDuty':'调试服务尚未就绪；请启动调试后端';document.querySelector('#backend-log').textContent=latest.backend_output||'尚未启动工作台调试会话';latest.channels.forEach((c,i)=>{rows[i].actual.textContent='实际脉宽：'+(c.duty_cycle_ns==null?'未初始化':(c.duty_cycle_ns/1e6).toFixed(3)+' ms')+' · 输出：'+(c.enabled?'开启':'关闭');});}catch(e){latest=null;statusLine.textContent=e.message;}controls();}
async function action(name,body={}){if(busy&&name!=='stop')return;busy=true;controls();try{const r=await api(name,{confirm:'舵机调试',...body});resultBox.textContent=JSON.stringify(r,null,2);await refresh();}catch(e){resultBox.textContent=e.message;}finally{busy=false;controls();}}
for(let i=0;i<3;i++){
 const card=document.createElement('section');card.className='servo-card';card.innerHTML='<h2>'+['1 · 后仓','2 · 右仓','3 · 左仓'][i]+'</h2><p class="actual">尚未读取实际状态</p><input type="range" min="0.5" max="2.5" step="0.01" value="1.5" aria-label="'+(i+1)+'号脉宽滑块"><label>脉宽 <input type="number" min="0.5" max="2.5" step="0.01" value="1.5" aria-label="'+(i+1)+'号脉宽毫秒"> ms</label><label><input type="checkbox" class="hold">保持输出</label><div><button class="send">发送到该舵机</button><button class="initial">填入归位值</button><button class="release">填入释放值</button></div>';
 document.querySelector('#channels').append(card);const range=card.querySelector('input[type=range]'),number=card.querySelector('input[type=number]');
 const row={actual:card.querySelector('.actual'),send:card.querySelector('.send')};rows.push(row);
 range.oninput=()=>number.value=range.value;number.oninput=()=>range.value=number.value;
 for(const [cls,key] of [['initial','initial_ns'],['release','release_ns']])card.querySelector('.'+cls).onclick=()=>{if(!latest)return;number.value=range.value=latest[key][i]/1e6;};
 row.send.onclick=()=>{const ms=Number(number.value);if(!Number.isFinite(ms)||ms<.5||ms>2.5){resultBox.textContent='脉宽须在0.5～2.5 ms之间';return;}const hold=card.querySelector('.hold').checked;if(!window.confirm('实际操作'+(i+1)+'号舵机：'+ms+' ms，'+(hold?'保持输出直到手动关闭':'输出约0.3秒后关闭')+'。确认执行？'))return;action('set',{slot:i+1,duty_cycle_ns:Math.round(ms*1e6),hold});};
}
document.querySelector('#ground').onchange=controls;
document.querySelector('#refresh').onclick=refresh;
document.querySelector('#start').onclick=()=>{if(window.confirm('仅启动板端调试节点；不会自动归位或释放。确认启动？'))action('start');};
document.querySelector('#stop').onclick=()=>action('stop');
document.querySelector('#close').onclick=()=>action('close');
refresh();setInterval(()=>{if(!document.hidden&&!busy)refresh();},3000);
